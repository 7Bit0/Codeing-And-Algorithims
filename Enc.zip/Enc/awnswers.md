3a) You make stuff unreadable

3b) You shift the char code of each letter buy an integer defined in a key

3c) You analyse the frequency of things and decrepit via that



