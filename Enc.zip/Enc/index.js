module.exports = {
    encrypt: require('./encrypt'),
    decrypt: require('./decrypt'),
}